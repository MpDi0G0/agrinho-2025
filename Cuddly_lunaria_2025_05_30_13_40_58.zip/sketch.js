let ship, bullets, enemies, enemyBullets, enemyLasers;
let shipSpeed = 5;
let shipVelocity = 0;
let friction = 0.95;
let score = 0;
let wave = 1;
let lives = 5; // Aumentado para 5 vidas
let lastEnemyShot = 0;
let boss = null;
let bossHealth = 0;

// Tipos de inimigos
const ENEMY_TYPES = {
  NORMAL: { emoji: "🐔", health: 1, points: 100, shotSpeed: 5, shotEmoji: "🥚", color: "rgb(255, 255, 255)" },
  TANK: { emoji: "🐄", health: 3, points: 300, shotSpeed: 3, shotEmoji: "🥛", color: "rgb(255, 100, 100)" },
  SNIPER: { emoji: "🐖", health: 2, points: 200, shotSpeed: 10, shotEmoji: "🔺", color: "rgb(100, 255, 100)" }
};

function setup() {
  createCanvas(600, 400);
  resetGame();
}

function resetGame() {
  ship = { 
    x: width / 2, 
    y: height - 50, 
    size: 30,
    isMoving: false
  };
  bullets = [];
  enemies = [];
  enemyBullets = [];
  enemyLasers = [];
  boss = null;
  lives = 5;
  createWave();
}

function createWave() {
  if (wave % 5 === 0) {
    createBoss();
  } else {
    const enemiesPerRow = min(5 + wave, 10);
    const rows = 1 + floor(wave / 3);
    
    for (let r = 0; r < rows; r++) {
      for (let i = 0; i < enemiesPerRow; i++) {
        // Escolhe tipo de inimigo baseado na onda
        let type;
        if (wave < 3) {
          type = ENEMY_TYPES.NORMAL;
        } else if (wave < 6) {
          type = random() > 0.7 ? ENEMY_TYPES.TANK : ENEMY_TYPES.NORMAL;
        } else {
          type = random() > 0.6 ? ENEMY_TYPES.TANK : 
                 random() > 0.4 ? ENEMY_TYPES.SNIPER : ENEMY_TYPES.NORMAL;
        }
        
        enemies.push({
          x: i * (width / (enemiesPerRow + 1)) + 50,
          y: 50 + r * 40,
          speed: 2 + wave * 0.2,
          lastShot: 0,
          type: type,
          health: type.health,
          isBoss: false
        });
      }
    }
  }
}

function createBoss() {
  boss = {
    x: width / 2,
    y: 80,
    size: 50,
    speed: 1 + wave * 0.1,
    health: 15 + wave * 3, // Boss mais resistente
    lastShot: 0,
    moveDirection: 1,
    isBoss: true,
    type: { emoji: "🐘", points: 1000, shotEmoji: "🔥", color: "rgb(255, 0, 0)" }
  };
  bossHealth = boss.health;
}

function draw() {
  background(0);
  
  // Movimentação da nave
  ship.x += shipVelocity;
  shipVelocity *= friction;
  ship.x = constrain(ship.x, ship.size/2, width - ship.size/2);
  
  // Desenha a nave
  textSize(ship.size);
  text(ship.isMoving ? "🚜" : "🚜", ship.x - ship.size/2, ship.y);
  ship.isMoving = false;
  
  updateBullets();
  
  if (boss) {
    updateBoss();
  } else {
    updateEnemies();
  }
  
  updateEnemyBullets();
  updateEnemyLasers(); // Novo: sistema de lasers
  
  drawHUD();
  
  checkWaveCompletion();
  checkGameOver();
}

function updateBullets() {
  textSize(20);
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].y -= 10;
    text("⭐", bullets[i].x, bullets[i].y);
    if (bullets[i].y < 0) bullets.splice(i, 1);
  }
}

function updateBoss() {
  textSize(boss.size);
  
  // Movimento do boss
  boss.x += boss.speed * boss.moveDirection;
  if (boss.x > width - 50 || boss.x < 50) {
    boss.moveDirection *= -1;
    boss.y += 20;
  }
  
  // Desenha o boss
  text(boss.type.emoji, boss.x - boss.size/2, boss.y);
  
  // Barra de vida
  drawBossHealth();
  
  // Padrão de tiro do boss
  if (millis() - boss.lastShot > 800) { // Boss atira mais rápido
    // Tiro triplo
    enemyBullets.push({ 
      x: boss.x - 20, 
      y: boss.y + 30,
      type: boss.type
    });
    enemyBullets.push({ 
      x: boss.x, 
      y: boss.y + 30,
      type: boss.type
    });
    enemyBullets.push({ 
      x: boss.x + 20, 
      y: boss.y + 30,
      type: boss.type
    });
    
    // Laser especial do boss a cada 3 tiros
    if (frameCount % 3 === 0) {
      enemyLasers.push({
        x: boss.x,
        y: boss.y + 40,
        width: 5,
        active: true,
        timer: 30 // Duração do laser
      });
    }
    
    boss.lastShot = millis();
  }
  
  // Colisão com tiros do jogador
  for (let i = bullets.length - 1; i >= 0; i--) {
    if (dist(bullets[i].x, bullets[i].y, boss.x, boss.y) < 40) {
      bullets.splice(i, 1);
      bossHealth--;
      
      if (bossHealth <= 0) {
        score += boss.type.points * wave;
        boss = null;
        wave++;
        setTimeout(createWave, 1000);
        break;
      }
    }
  }
}

function updateEnemies() {
  textSize(30);
  for (let i = enemies.length - 1; i >= 0; i--) {
    let enemy = enemies[i];
    
    // Movimento
    enemy.x += enemy.speed;
    if (enemy.x > width - 15 || enemy.x < 15) {
      enemy.speed *= -1;
      enemy.y += 30;
    }
    
    // Desenha com cor específica
    fill(enemy.type.color);
    text(enemy.type.emoji, enemy.x - 15, enemy.y);
    fill(255); // Reset para branco
    
    // Comportamento de tiro específico
    if (millis() - enemy.lastShot > 1500 && random() < 0.03) {
      if (enemy.type === ENEMY_TYPES.SNIPER) {
        // Inimigo sniper atira laser
        enemyLasers.push({
          x: enemy.x,
          y: enemy.y + 20,
          width: 3,
          active: true,
          timer: 15 // Laser mais curto
        });
      } else {
        // Outros inimigos atiram projéteis normais
        enemyBullets.push({ 
          x: enemy.x, 
          y: enemy.y + 20,
          type: enemy.type
        });
      }
      enemy.lastShot = millis();
    }
    
    // Colisão com tiros do jogador
    for (let j = bullets.length - 1; j >= 0; j--) {
      if (dist(bullets[j].x, bullets[j].y, enemy.x, enemy.y) < 20) {
        bullets.splice(j, 1);
        enemy.health--;
        
        if (enemy.health <= 0) {
          score += enemy.type.points * wave;
          enemies.splice(i, 1);
          break;
        }
      }
    }
  }
}

function updateEnemyBullets() {
  textSize(20);
  for (let i = enemyBullets.length - 1; i >= 0; i--) {
    let bullet = enemyBullets[i];
    
    // Movimento baseado no tipo
    bullet.y += bullet.type.shotSpeed;
    fill(bullet.type.color);
    text(bullet.type.shotEmoji, bullet.x - 10, bullet.y);
    fill(255);
    
    if (bullet.y > height) {
      enemyBullets.splice(i, 1);
      continue;
    }
    
    if (dist(bullet.x, bullet.y, ship.x, ship.y) < 20) {
      enemyBullets.splice(i, 1);
      lives--;
      if (lives <= 0) {
        textSize(32);
        text("💥 Nave Destruída!", width/2 - 120, height/2);
      }
      break;
    }
  }
}

// Novo: sistema de lasers
function updateEnemyLasers() {
  for (let i = enemyLasers.length - 1; i >= 0; i--) {
    let laser = enemyLasers[i];
    
    // Desenha o laser
    fill(255, 0, 0, 150);
    rectMode(CENTER);
    rect(laser.x, laser.y + height/2, laser.width, height);
    fill(255);
    
    // Verifica colisão com jogador
    if (laser.active && abs(ship.x - laser.x) < 15) {
      lives--;
      laser.active = false; // Evita dano contínuo
      if (lives <= 0) {
        textSize(32);
        text("", width/2 - 120, height/2);
      }
    }
    
    // Contador de duração
    laser.timer--;
    if (laser.timer <= 0) {
      enemyLasers.splice(i, 1);
    }
  }
}

function drawBossHealth() {
  const barWidth = 200;
  const healthPercent = bossHealth / boss.health;
  
  fill(255, 0, 0);
  rect(width/2 - barWidth/2, 40, barWidth, 10);
  
  fill(0, 255, 0);
  rect(width/2 - barWidth/2, 40, barWidth * healthPercent, 10);
  
  fill(255);
  textSize(16);
  text(`BOSS: ${bossHealth}/${boss.health}`, width/2 - 40, 35);
}

function drawHUD() {
  textSize(24);
  fill(255);
  let bossText = boss ? "| BOSS FIGHT!" : "";
  text(`Score: ${score} | Wave: ${wave} ${bossText} | Lives: ${"❤️".repeat(max(0, lives))}`, 20, 30);
}

function checkWaveCompletion() {
  if ((!boss && enemies.length === 0) || (boss && bossHealth <= 0)) {
    if (!boss) {
      wave++;
      createWave();
    }
  }
}

function checkGameOver() {
  if ((enemies.some(e => e.y >= height - 50) || lives <= 0 || (boss && boss.y >= height - 50))) {
    textSize(32);
    text("💥 Game Over!", width/2 - 100, height/2);
    noLoop();
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    shipVelocity = -shipSpeed;
    ship.isMoving = true;
  }
  if (keyCode === RIGHT_ARROW) {
    shipVelocity = shipSpeed;
    ship.isMoving = true;
  }
  if (key === ' ') {
    bullets.push({ x: ship.x, y: ship.y - ship.size/2 });
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    ship.isMoving = false;
  }
} 